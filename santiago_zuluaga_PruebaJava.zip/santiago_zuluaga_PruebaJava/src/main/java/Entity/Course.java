package Entity;

import java.sql.Date;

public class Course {
    //Private attributes of the Course class
    private int id;
    private String name;
    private Date creation_date;
    private String description;

    //Default constructor (no parameters)
    public Course() {
    }

    //Constructor with parameters to initialize attributes
    public Course(int id, String name, Date creation_date, String description) {
        this.id = id;
        this.name = name;
        this.creation_date = creation_date;
        this.description = description;
    }

    //Getters and setters methods to access and modify private attributes
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getCreation_date() {
        return creation_date;
    }

    public void setCreation_date(Date creation_date) {
        this.creation_date = creation_date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    //ToString method to represent the Coder object as a text string
    @Override
    public String toString() {
        return "Course{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", creation_date=" + creation_date +
                ", description='" + description + '\'' +
                '}';
    }
}
