package Entity;

import java.util.Date;

public class Student {
    //Private attributes of the Student class
    private int id;
    private String name;
    private String lastname;
    private String email;
    private boolean State;
    private Date creation_date;

    //Default constructor (no parameters)
    public Student(int id, String name, String lastname, String email, boolean state, String creation_date) {
    }

    //Constructor with parameters to initialize attributes
    public Student(int id, String name, String lastname, String email, boolean state, Date creation_date) {
        this.id = id;
        this.name = name;
        this.lastname = lastname;
        this.email = email;
        State = state;
        this.creation_date = creation_date;
    }

    public static boolean getState() {
    }

    public static int getLastName() {
    }

    //Getters and setters methods to access and modify private attributes
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public static String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public static String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isState() {
        return State;
    }

    public void setState(boolean state) {
        State = state;
    }

    public static String getCreation_date() {
        return creation_date;
    }

    public void setCreation_date(Date creation_date) {
        this.creation_date = creation_date;
    }

    //ToString method to represent the Coder object as a text string
    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", lastname='" + lastname + '\'' +
                ", email='" + email + '\'' +
                ", State=" + State +
                ", creation_date=" + creation_date +
                '}';
    }
}
