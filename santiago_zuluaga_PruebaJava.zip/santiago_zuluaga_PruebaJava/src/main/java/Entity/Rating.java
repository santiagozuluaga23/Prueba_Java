package Entity;

public class Rating {
    //Private attributes of the Rating class
    private int id;
    private double raiting;
    private String description;
    private int registration_id;

    //Default constructor (no parameters)
    public Rating() {
    }

    //Constructor with parameters to initialize attributes
    public Rating(int id, double raiting, String description, int registration_id) {
        this.id = id;
        this.raiting = raiting;
        this.description = description;
        this.registration_id = registration_id;
    }

    //Getters and setters methods to access and modify private attributes
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getRaiting() {
        return raiting;
    }

    public void setRaiting(double raiting) {
        this.raiting = raiting;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getRegistration_id() {
        return registration_id;
    }

    public void setRegistration_id(int registration_id) {
        this.registration_id = registration_id;
    }

    //ToString method to represent the Coder object as a text string
    @Override
    public String toString() {
        return "Rating{" +
                "id=" + id +
                ", raiting=" + raiting +
                ", description='" + description + '\'' +
                ", registration_id=" + registration_id +
                '}';
    }
}
