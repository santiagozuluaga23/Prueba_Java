package Entity;

import java.sql.Date;

public class Registration {
    //Private attributes of the Registration class
    private int id;
    private Date registration_date;
    private int student_id;
    private int course_id;

    //Default constructor (no parameters)
    public Registration() {
    }

    //Constructor with parameters to initialize attributes
    public Registration(int id, Date registration_date, int student_id, int course_id) {
        this.id = id;
        this.registration_date = registration_date;
        this.student_id = student_id;
        this.course_id = course_id;
    }

    //Getters and setters methods to access and modify private attributes
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getRegistration_date() {
        return registration_date;
    }

    public void setRegistration_date(Date registration_date) {
        this.registration_date = registration_date;
    }

    public int getStudent_id() {
        return student_id;
    }

    public void setStudent_id(int student_id) {
        this.student_id = student_id;
    }

    public int getCourse_id() {
        return course_id;
    }

    public void setCourse_id(int course_id) {
        this.course_id = course_id;
    }

    //ToString method to represent the Coder object as a text string
    @Override
    public String toString() {
        return "Registration{" +
                "id=" + id +
                ", registration_date=" + registration_date +
                ", student_id=" + student_id +
                ", course_id=" + course_id +
                '}';
    }
}
