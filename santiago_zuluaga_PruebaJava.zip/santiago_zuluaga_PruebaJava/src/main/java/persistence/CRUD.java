package persistence;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public interface CRUD {
    public Object create(Object object) throws SQLException;
    public Object readById(int id);
    public ArrayList<Object> readAll();
    public Object update(Object Object, int id);
    public Boolean delete(int id);

    List<Object> findAll();
}
