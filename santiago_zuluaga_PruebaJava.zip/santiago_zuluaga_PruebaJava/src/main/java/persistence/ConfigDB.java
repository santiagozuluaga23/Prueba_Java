package persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConfigDB {

    //Method to open connection
    static Connection connection = null;

    public static Connection openConnection(){

        try{
            //Install drivers
            Class.forName("com.mysql.cj.jdbc.Driver");

            //Credentials
            String URL = "jdbc:mysql://localhost:3306/RiwiAcademyDB";
            String user = "root";
            String password = "Rlwl2023.";

            //Establish the connection
            connection = DriverManager.getConnection(URL, user, password);
            System.out.println("Established connection");

        }catch (ClassNotFoundException e){
            System.out.println("ERROR: Driver not found");
        }catch(SQLException e){
            System.out.println("ERROR: Connection failed");
        }

        return connection;

    }

    //Method to close connection
    public static void closeConnection()throws SQLException{

        try{
            if (connection !=null) {
                connection.close();
                System.out.println("Connection finished");
            }
        }catch(SQLException e){
            System.out.println("ERROR: Connection not finished");
        }
    }
}
