/*Creating the database with the required name*/
create database RiwiAcademyDB;

/*Use previously created database*/
use RiwiAcademyDB;

/*Creation of tables with their respective attributes, and these with their data types*/
create table students(
	id int primary key auto_increment,
    name varchar(255) not null,
    lastname varchar(255) not null,
	email varchar(255) unique not null,
    state boolean default true,
    creation_date date not null,
    CHECK (state IN (0, 1))
);

create table courses(
	id int primary key auto_increment,
    name varchar(255) unique not null,
    creation_date date not null,
    description varchar(255) not null
);

create table registrations(
	id int primary key auto_increment,
    registration_date date,
    student_id int not null,
    course_id int not null,
    foreign key (student_id) references students(id) ON DELETE CASCADE,
    foreign key (course_id) references courses(id) ON DELETE CASCADE,
    UNIQUE (student_id, course_id),
    CHECK (student_id IS NOT NULL AND course_id IS NOT NULL)
);

create table ratings(
	id int primary key auto_increment,
	raiting double not null,
    description varchar(255) not null,
    registration_id INT NOT NULL,
    rating double CHECK (rating between 0 and 100),
    foreign key (registration_id) references registrations(id) ON DELETE CASCADE
);