package model;

import Entity.Student;
import persistence.ConfigDB;
import persistence.CRUD;
import javax.swing.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class StudentModel implements CRUD {
    @Override
    public Object create(Object object) {

        Connection connection = ConfigDB.openConnection();

        Student student = (Student) object;

        try {
            String sqlQuery = "INSERT INTO students(name, lastname, email, state, creation_date) VALUES (?,?,?,?,?);";
            PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery, PreparedStatement.RETURN_GENERATED_KEYS);

            preparedStatement.setString(1, Student.getEmail());
            preparedStatement.setString(2, Student.getLastname());
            preparedStatement.setString(3, Student.getEmail());
            preparedStatement.setBoolean(4, Student.getState());
            preparedStatement.setString(5, Student.getCreation_date());

            preparedStatement.execute();

            ResultSet result = preparedStatement.getGeneratedKeys();

            while (result.next()) {
                student.setId((result.getInt(1)));
            }

            preparedStatement.close();

            JOptionPane.showMessageDialog(null, "The student has been created successfull", sqlQuery, 0);

        } catch (SQLException e) {
            System.out.println("The student could not be created correctly");
        }

        try {
            ConfigDB.closeConnection();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return student;
    }

    public Boolean delete(int id) {

        Connection connection = ConfigDB.openConnection();

        try {

            String sqlQuery = "DELETE FROM students WHERE id = ?;";

            PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);

            preparedStatement.setInt(1, id);

            int idEliminar = preparedStatement.executeUpdate();

            preparedStatement.close();

            if (idEliminar > 0) {
                JOptionPane.showMessageDialog(null, "The has been successfull removed", sqlQuery, idEliminar);
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "The student with that ID was not found", sqlQuery, idEliminar);
                return false;
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "The student could not deleted correctly", null, id);
            return false;
        } finally {
            try {
                ConfigDB.closeConnection();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }

    @Override
    public List<Object> findAll() {
        return null;
    }

    @Override
    public Object readById(int id) {

        Connection connection = ConfigDB.openConnection();

        Student student = null;

        try {

            String sqlQuery = "SELECT * FROM students WHERE id = ?;";

            PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
            preparedStatement.setInt(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                String name = resultSet.getString("name");
                String lastname = resultSet.getString("lastname");
                String email = resultSet.getString("email");
                boolean state = resultSet.getBoolean("state");
                String creation_date = resultSet.getString("creation_name");

                student = new Student(id, name, lastname, email, state, creation_date);
            }

        } catch (SQLException e) {
            System.out.println("ERROR: Student could not be consulted: ");
        }

        try {
            ConfigDB.closeConnection();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    @Override
    public ArrayList<Object> readAll() {
        return null;
    }

    @Override
    public Object update(Object Object, int id) {
        return null;
    }

    @Override
        public ArrayList<Student> readByModel (int id, String email){
            // Abrir conexión
            Connection connection = ConfigDB.openConnection();
            ArrayList<Student> students = new ArrayList<>();

            try {

                String sqlQuery = "SELECT * FROM students WHERE id = ?;";
                PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);

                // Ejecutar el query
                ResultSet resultSet = preparedStatement.executeQuery();

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error when searching for student", "Error", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            } finally {
                try {
                    ConfigDB.closeConnection();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            return student;
        }
    }
}