package org.example;

import java.sql.*;

import persistence.ConfigDB;

public class Main {
    public static void main(String[] args) throws SQLException {

        ConfigDB.openConnection();



        ConfigDB.closeConnection();
    }
}