package controller;

import model.StudentModel;

import javax.swing.*;

public class StudentController {

    //Model attribute
    StudentModel objStudentModel;

    public StudentController(){
        //Create the model instance
        this.objStudentModel = new StudentModel();
    }

    public void create(){

        //Insert students name
        String name = JOptionPane.showInputDialog("Insert student's name: ");

        //Insert lastname
        String lastName = JOptionPane.showInputDialog(("Insert student's last name:  "));

        //Insert email
        String email = JOptionPane.showInputDialog(("Insert the student's email address: "));

        Students objStudent = new Students(name, lastName, email);

        Students result = (Students) this.objStudentModel.create(objStudent);

        JOptionPane.showMessageDialog(null,result);

    }

    public void update(){

        //Ask for the id to be updated
        int id_Update = Integer.parseInt(JOptionPane.showInputDialog("Enter the id to update: "));

        //New info Stundents
        String newName = JOptionPane.showInputDialog("Insert the new name: ");
        String newLastName = JOptionPane.showInputDialog("Insert the new lastname: ");
        String newEmail = JOptionPane.showInputDialog("Insert the new email: ");
        Boolean newState = Boolean.valueOf(JOptionPane.showInputDialog("Insert the new state: "));
        String newCreation_date = JOptionPane.showInputDialog("Insert the new creation date: ");

        //Update object
        Students studentsUpdate = new Students(id_Update, newName, newLastName, newEmail);

        this.objStudentModel.update(studentsUpdate, id_Update);

    }
